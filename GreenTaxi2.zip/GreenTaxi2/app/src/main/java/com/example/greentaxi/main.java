package com.example.greentaxi;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;


public class main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

    }



    public void onClick(View view){

        switch (view.getId()){
            case R.id.login:
                Intent login = new Intent(this, main_login.class);
                startActivity(login);
                break;

            case R.id.signUp:
                Intent signUp = new Intent(this, signUp.class);
                startActivity(signUp);
                break;

        }

    }
}
