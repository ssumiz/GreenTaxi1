package com.example.greentaxi;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.view.*;

public class main_login extends AppCompatActivity {

    ListView listView ;
    EditText editText;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_login);

        editText = (EditText) findViewById(R.id.main_search);

    }

    public void onClick(View view){
        switch (view.getId()){
            case R.id.main_search:
                Intent intent = new Intent(this , route_search.class );
                break;

            case R.id.main_alarm:
                break;

            case R.id.main_record:
                break;

            case R.id.main_sos:
                break;

            case R.id.main_serviceCenter:
                break;
        }

    }



}
