package com.example.greentaxi;

public class QrcodeReaderActivity {
}
