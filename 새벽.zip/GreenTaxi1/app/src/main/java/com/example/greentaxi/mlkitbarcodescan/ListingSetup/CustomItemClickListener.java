package com.example.greentaxi.mlkitbarcodescan.ListingSetup;

import android.view.View;

/**
 * Created by Jaison.
 */
public interface CustomItemClickListener {
     void onItemClick(View v, int position);

}
